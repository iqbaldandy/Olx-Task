<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="assets/css/login.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<body>
	
	<div class="content">		
		<div class="account entry">
			<div class="baris">
				<div>
				<a href="#"><img src="assets/img/logo.jpg"width="70px"class="logo"></a>		
				</div>
				<form action="<?php echo base_url('login/aksi_login'); ?>" method="post" class="typeform">
					<h3 class="tengah">Login</h3>
					<div class="form-group">
				    <label for="username">Email address</label>
				    <input type="email" class="form-control" name="email" aria-describedby="emailHelp" placeholder="Enter email">
				  </div>
				  <div class="form-group">
				    <label for="password">Password</label>
				    <input type="password" class="form-control" name="password" placeholder="Password">
				  </div>
				  <button  class="btn btn-primary" id="extend">Login</button>
				  <div class="no-account text-center">
							<!--isi link Regist-->
		                    <p> <a href="<?php echo base_url('register'); ?>">Register a new account</a></p>
				  </div>
				</form>
			</div>
		</div>
	</div>
</body>
<footer style="background: #D9D9D9;">
    <div class="footer">
        <div class="row" style="height: 2px; width: 1364px;">
            <div class="col-4" style="background: #628;"></div>
            <div class="col-4" style="background: #aab20a;"></div>
            <div class="col-4" style="background: #ff7900;"></div>
        </div>
        <div class="row" style="padding-top: 50px;">
            <div class="container">
                <div class="row">
                    <div class="col-6">
                            <img src="assets/img/get-it-on-google-play.png" style="width: 135px; height: 40px;">
                            <img src="assets/img/download-on-the-app-store.png" style="width: 135px; height: 40px;">
                    </div>
                    <div class="col-6">
                        <button type="button" class="btn btn-warning" style="background-color:#FF7700; float:right; color: #ffffff">Sell Your Item Now</button>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="group-name">OLX Group</div>
                        <div class="links">
                            <span class="title">OLX:</span> 
                        </div>
                        
                    </div>
                    <div class="col-12">
                        <div class="copyright">
                            <p><i class="far fa-copyright"></i> 2019 OLX Philippines</p>
                        </div>
                        <div>
                            <a href="" target="_blank">Corporate</a>
                            <a href="" target="_blank">About OLX</a>
                            <a href="" target="_blank">Careers</a>
                            <a href="" target="_blank">Privacy Policy</a>
                            <a href="" target="_blank">Blog</a>
                            <a href="" target="_blank">South Africa</a>
                            <a href="" target="_blank">view ads in OLX</a>
                            <a href="" target="_blank">Help Center</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
</html>