<!DOCTYPE html>
<html>
<head>
	<link rel="icon" href="olx.png" class="rounded">
	<title>Lihat Iklan</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="Asset/css/palinganyar.css">

  <style type="text/css">
	  body {
		  background-color: white;
	  }
	  /*.size{
	  	margin-right: 106px;
	  	margin-left: 106px;
	  }*/

  </style>
</head>

<header>
    <div class="main-wrapper container">
        <div class="home">
            <nav class="navbar navbar-light" style="background-color:#4A117A;">
                <a class="navbar-brand" href="#">
                    <svg width="44px" height="44px" viewBox="-1 -1 44 44" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" class="">
                        <g id="logo">
                            <circle id="Oval-9" stroke="" fill="#FFFFFF" cx="21" cy="21" r="21"></circle>
                            <path d="M37.1944562,14.3984977 C37.1944562,14.3984977 37.3752857,14.0963318 37.3743641,13.7161014 C37.3743641,13.3171613 37.1180507,12.8165622 36.406576,12.8165622 C35.5194793,12.8165622 34.9362995,13.4555484 34.9362995,13.4555484 L31.3691567,17.5561935 C31.3691567,17.5561935 29.576576,14.8825069 28.9559309,13.9331982 C28.3417834,13.0652719 27.2933502,13.0957327 27.2933502,13.0957327 C27.2933502,13.0957327 26.774318,13.0458249 26.3007235,13.4245346 C25.6826129,13.959788 25.8912765,14.8017235 25.8912765,14.8017235 L28.738788,20.6580369 L24.6319217,25.2984055 C23.9770829,26.3418618 24.4272212,27.3146267 24.4272212,27.3146267 L25.5128894,29.0702488 C25.5128894,29.0702488 25.8478664,29.6596037 26.3751935,29.6596037 C26.9025207,29.6596037 27.2127051,29.1074839 27.2127051,29.1074839 L30.5316452,24.200341 C30.5316452,24.200341 32.8518756,28.4374839 33.3915991,29.4610783 C33.7432581,30.098682 34.6499862,30.3450415 35.1224286,30.2241659 C35.5948249,30.1032442 37.2874977,29.6534286 37.8024286,29.4921382 C38.3325207,29.3220922 38.4910461,28.8903871 38.4910461,28.5429677 C38.4910461,28.2699724 38.3359309,28.0156406 38.3359309,28.0156406 L33.1992488,20.2982212 L37.1944562,14.3984977 Z" id="Fill-3" fill="#F37820"></path>
                            <path d="M25.1158341,21.5782535 C25.1158341,21.1290829 24.5672166,20.8999585 24.007447,20.8999585 L21.0792903,20.8999585 C20.2348664,20.8999585 20.1694286,20.4007419 20.1694286,19.7998664 L20.1694286,12.1072396 C20.1694286,11.5973779 19.8137143,10.9409724 18.9865714,10.9409724 L17.3777235,10.9409724 C16.8927926,10.9409724 16.3438065,11.4917558 16.3438065,12.1899585 C16.3438065,12.7140138 16.3479078,21.4293594 16.3479078,22.9017097 C16.3479078,24.0088986 17.1326083,24.4484839 17.828553,24.4484839 L23.8916406,24.4484839 C24.9478618,24.4484839 25.1158341,23.820235 25.1158341,23.5138295 L25.1158341,21.5782535 Z" id="Fill-5" fill="#A7B437"></path>
                            <path d="M8.88693088,26.7149263 C6.84425806,26.7149263 5.71891244,23.833682 5.71891244,21.3466313 C5.71891244,17.9126221 7.37029493,15.8873687 8.81250691,15.8873687 C10.5963318,15.8873687 12.0136129,18.3532212 12.0136129,21.297 C12.0136129,23.9075069 10.7728756,26.7149263 8.88693088,26.7149263 M8.88693088,13.33147 C5.10333641,13.33147 2.07937327,16.8386129 2.07937327,21.4045576 C2.07937327,25.8981521 5.42845161,29.2956636 8.81250691,29.2956636 C12.9563779,29.2956636 15.6283134,25.2498111 15.6283134,21.3962627 C15.6283134,16.5994885 12.3649032,13.33147 8.88693088,13.33147" id="Fill-7" fill="#4F2D7E"></path>
                        </g>
                    </svg>
                </a>
                <ul class="nav nav-pills float-right">
                    <li class="nav-item">
                        <a class="nav-link active" id="btn1" href="">Sell Your Item Now
                            <span class="sr-only">(current)</span>                                    
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="btn2" href="">
                            <img class="img-fluid" width="14" height="13" src="assets/img/user.png"><?= $this->session->userdata('nama'); ?>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</header>
<body>
	<div>
		<div class="main-wrapper container">
			<table class="table table-striped" id="table">
		        <thead>
		          <tr>
		            <th style="width:20px;">No</th>
		            <th style="width:200px;">Judul</th>
		            <th style="width:80px;">Location</th>
		            <th style="width:400px;">Description</th>
		            <th style="width:100px;">Harga</th>
		            <th style="width: 30px;">Edit</th>
		            <th style="width: 30px;">Hapus</th>
		          </tr>
		        </thead>
        <tbody>
          <?php
           $data = $this->session->all_data;
           $no=1; foreach ($data as $d ) { ?>
          <tr>
        <!--HINT UNTUK MENGHAPUS USER KALIAN DAPAT MENGGUNAKAN FORM, MENGGUNAKAN ANCHOR ATAU HREF PADA BUTTON-->
            <form action="">
              <td><?php echo $no++ ?></td>
              <td><h3><?php echo $d->nama_iklan ?></h3></td>
              <td>
              	<h5><?php echo $d->provinsi_iklan?></h5>
              	<p><?php echo $d->kota_iklan ?></p>
              	<div><?php echo $d->kategori_iklan ?></div>
              </td>
              <td><p><?php echo $d->deskripsi_iklan ?></p>
              	
              </td>
              <td><?php echo $d->harga?></td>
              <!--BUTTON EDIT MAHASISWA-->
              <td><button type="button" class="btn btn-warning" data-toggle="modal" data-target="#"><i class="fas fa-user-edit"></i></button></td>
              <!--BUTTON HAPUS --- ISI LENGKAPI BUTTON INI -->
              <td><a type="button" class="btn btn-danger"  href="#" onClick="return confirm('Apakah Anda Yakin?')" ><i class="fas fa-user-times"></i></a>
              </td>
              >
            </form>
          </tr>
    <?php } ?>
        </tbody>
      </table>
		</div>
	</div>
</body>
<footer style="background: #D9D9D9;">
    <div class="footer">
        <div class="row" style="height: 2px; width: 1364px;">
            <div class="col-4" style="background: #628;"></div>
            <div class="col-4" style="background: #aab20a;"></div>
            <div class="col-4" style="background: #ff7900;"></div>
        </div>
        <div class="row" style="padding-top: 50px;">
            <div class="container">
                <div class="row">
                    <div class="col-6">
                            <img src="assets/img/get-it-on-google-play.png" style="width: 135px; height: 40px;">
                            <img src="assets/img/download-on-the-app-store.png" style="width: 135px; height: 40px;">
                    </div>
                    <div class="col-6">
                        <button type="button" class="btn btn-warning" style="background-color:#FF7700; float:right; color: #ffffff">Sell Your Item Now</button>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="group-name">OLX Group</div>
                        <div class="links">
                            <span class="title">OLX:</span>
                            <a href="" target="_blank">Bahrain</a>
                            <a href="" target="_blank">Indonesia</a>
                            <a href="" target="_blank">Kuwait</a>
                            <a href="" target="_blank">Lebanon</a>
                            <a href="" target="_blank">Oman</a>
                            <a href="" target="_blank">Philippines</a>
                            <a href="" target="_blank">Qatar</a>
                            <a href="" target="_blank">Saudi Arabia</a>
                        </div>
                        <div>
                            <span class="title">dubizzle:</span>
                            <a href="" target="_blank">Dubai</a>
                            <a href="" target="_blank">Abu Dhabi</a>
                            <a href="" target="_blank">Ras al Khaimah</a>
                            <a href="" target="_blank">Sharjah</a>
                            <a href="" target="_blank">Fujairah</a>
                            <a href="" target="_blank">Ajman</a>
                            <a href="" target="_blank">Umm al Quwain</a>
                            <a href="" target="_blank">Al Ain</a>
                        </div>
                        <div>
                            <span class="title">Property24:</span>
                            <a href="" target="_blank">Botswana</a>
                            <a href="" target="_blank">Kenya</a>
                            <a href="" target="_blank">Namibia</a>
                            <a href="" target="_blank">Nigeria</a>
                            <a href="" target="_blank">Philippines</a>
                            <a href="" target="_blank">South Africa</a>
                            <a href="" target="_blank">Zambia</a>
                            <a href="" target="_blank">Zimbabwe</a>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="copyright">
                            <p><i class="far fa-copyright"></i> 2019 OLX Philippines</p>
                        </div>
                        <div>
                            <a href="" target="_blank">Corporate</a>
                            <a href="" target="_blank">About OLX</a>
                            <a href="" target="_blank">Careers</a>
                            <a href="" target="_blank">Privacy Policy</a>
                            <a href="" target="_blank">Blog</a>
                            <a href="" target="_blank">South Africa</a>
                            <a href="" target="_blank">view ads in OLX</a>
                            <a href="" target="_blank">Help Center</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
</html>