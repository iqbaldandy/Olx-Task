<?php 

class M_iklan extends CI_Model{	

    // public function upload($image){
    //     $config['upload_path'] = './images/';
    //     $config['allowed_types'] = 'jpg|png|jpeg';
    //     $config['max_size']  = '2048';
    //     $config['remove_space'] = TRUE;
      
    //     $this->load->library('upload', $config); // Load konfigurasi uploadnya
    //     if($this->upload->do_upload('input_gambar')){ // Lakukan upload dan Cek jika proses upload berhasil
    //       // Jika berhasil :
    //       $return = array('result' => 'success', 'file' => $this->upload->data(), 'error' => '');
    //       return $return;
    //     }else{
    //       // Jika gagal :
    //       $return = array('result' => 'failed', 'file' => '', 'error' => $this->upload->display_errors());
    //       return $return;
    //     }
    //   }

    public function getAllIklan(){

	    $this->db->from('iklan');
		$this->db->order_by('substr(Id_iklan, 5) + 0');

	    $query = $this->db->get();
	    return $query->result();
    }
    
	function inputiklan($id_iklan,$nama_iklan,$provinsi,$kota,$kategori,$deskripsi,$harga){
        $email = $this->session->userdata('email');
		$data = array(
			'id_iklan' => $id_iklan,
			'nama_iklan' => $nama_iklan,
            'provinsi_iklan' => $provinsi,
            'kota_iklan' => $kota,
            'kategori_iklan' => $kategori,
            'deskripsi_iklan' => $deskripsi,
            // 'gambar_paket' => $upload['file']['file_name'],
            'harga' => $harga,
            'email' => $this->session->userdata('email')
		);	
		$this->db->insert('iklan', $data);
    }
    
    function editiklan($id_iklan,$nama_iklan,$provinsi,$kota,$kategori,$deskripsi,$harga)
    {
        $email = $this->session->userdata('email');
		$data = array(
			'id_iklan' => $id_iklan,
			'nama_iklan' => $nama_iklan,
            'provinsi_iklan' => $provinsi,
            'kota_iklan' => $kota,
            'kategori_iklan' => $kategori,
            'deskripsi_iklan' => $deskripsi,
            // 'gambar_paket' => $upload['file']['file_name'],
            'harga' => $harga,
            'email' => $this->session->userdata('email')
		);	
		$this->db->insert('iklan', $data);
    }
}