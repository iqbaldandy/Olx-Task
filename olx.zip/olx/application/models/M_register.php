<?php 

class M_register extends CI_Model{	

	function register($email,$name,$password){	
		$data = array(
			'email' => $email,
			'name' => $name,
			'password' => md5($password),
		);	
		$this->db->insert('users', $data);
	}	
}