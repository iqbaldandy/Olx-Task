<?php 

class iklan extends CI_Controller{

	function __construct(){
		parent::__construct();
				$this->load->model('M_iklan');
				$this->load->helper(array('form', 'url'));

				if($this->session->userdata('status') != "login"){
					redirect(base_url("login"));
				}
		}

	function index(){
		$this->load->view('v_input-iklan');
    }
    
    public function aksi_inputiklan(){
				$id_iklan 					= $this->input->post('idiklan');
        $nama_iklan         = $this->input->post('nama');
       	$provinsi	        	= $this->input->post('provinsi');
        $kota               = $this->input->post('kota');
        $kategori 	        = $this->input->post('kategori');
        $deskripsi 	        = $this->input->post('deskripsi');
        $harga              = $this->input->post('harga');

				// $image = $this->input->post('image');
				// $upload = $this->M_iklan->upload($image);

				// if($upload['result'] == "success"){
				// 	$this->M_iklan->inputiklan($id_iklan,$nama_iklan,$provinsi,$kota,$kategori,$deskripsi,$upload);
				// 	redirect(base_url('user'));
				// }else{
				// 	echo "gagal";
				// }
				
				$this->M_iklan->inputiklan($id_iklan,$nama_iklan,$provinsi,$kota,$kategori,$deskripsi,$harga);
				redirect(base_url("user"));
			
			}

			public function editiklan()
			{
				$id_iklan 					= $this->input->post('idiklan');
        $nama_iklan         = $this->input->post('nama');
       	$provinsi	        	= $this->input->post('provinsi');
        $kota               = $this->input->post('kota');
        $kategori 	        = $this->input->post('kategori');
        $deskripsi 	        = $this->input->post('deskripsi');
        $harga              = $this->input->post('harga');

				// $image = $this->input->post('image');
				// $upload = $this->M_iklan->upload($image);

				// if($upload['result'] == "success"){
				// 	$this->M_iklan->inputiklan($id_iklan,$nama_iklan,$provinsi,$kota,$kategori,$deskripsi,$upload);
				// 	redirect(base_url('user'));
				// }else{
				// 	echo "gagal";
				// }
				
				$this->M_iklan->editiklan($id_iklan,$nama_iklan,$provinsi,$kota,$kategori,$deskripsi,$harga);
				redirect(base_url("user"));
			
			}
			}

			public function hapusiklan()
			{
				$id = $_GET['id_iklan'];
	
					$this->Model_Feedback->hapusfeedback($id);
	
					//redirect
					redirect('admin/feedback');
	
			}
}
