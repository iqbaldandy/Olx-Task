<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class view_iklan extends CI_Controller {
	public function __construct()
	  {
	    parent::__construct();
	    $this->load->model('M_iklan');
	    $this->load->helper(array('form', 'url'));
      }
      
	public function index()
	{
		$data = $this->M_iklan->getAllIklan();
		$this->session->set_userdata('all_data',$data);

		$this->load->view('v_all-iklan');
    }
}