<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class register extends CI_Controller {
    function __construct(){
		parent::__construct();		
		$this->load->model('M_register');
 
	}
 
	function index(){
		$this->load->view('v_register');
	}
 
	function aksi_register(){
		$email = $this->input->post('email');
		$name = $this->input->post('name');
		$password = $this->input->post('password');
		$password2 = $this->input->post('password2');
		if ($password == $password2){
			$this->M_register->register($email,$name,$password);
			redirect(base_url("login"));
		}else{
			$message = "password confirmation not same";
			echo "<script type='text/javascript'>
				   			alert('$message');
				   			window.location.href = '" . base_url() . "register';
				   		  </script>";
		}
		
	}
 
	function logout(){
		$this->session->sess_destroy();
		redirect(base_url('login'));
	}
}
?>